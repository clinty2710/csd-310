from __future__ import print_function
import mysql.connector
from mysql.connector import errorcode

config = {
    'user': 'root',
    'password': 'Studman081!',
    'host': 'localhost',
    'database': 'bacchus_winery',
    'raise_on_warnings': True
}
try:
    mydb = mysql.connector.connect(**config)

    print("\n Database user {} connected to MySQL on host {} with database {}".format(
        config["user"], config["host"], config["database"]))
    input("\n\n Press any key to continue...\n")

except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print(" The supplied username or password are invalid")
    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print(" The specified database does not exist")
    else:
        print(err)

DB_NAME = 'bacchus_winery'

myCursor = mydb.cursor()

print("-Displaying Distribution Information-")

query2 = "SELECT orders.order_id AS 'Order Number', distributors.distributor_name AS 'Distributor " \
         "Name', orders.order_date AS 'Date',wine.wine_name AS 'Distributes', orders.bottles AS " \
         "'Bottles Ordered' FROM orders INNER JOIN distributors ON distributors.distributor_id = " \
         "orders.distributor_id INNER JOIN wine ON wine.wine_id = orders.wine_id ORDER BY " \
         "distributor_name"
myCursor.execute(query2)
distributors = myCursor.fetchall()
for distributor in distributors:
    print("Order Number: {}\nDistributor Name: {}\nOrder Date: {}\nWine Ordered: {}\nBottles "
          "Ordered: {}\n".format (distributor[0], distributor[1], distributor[2], distributor[3],
                                  distributor[4]))

print("-Displaying Wine Bought by Distributors Information-")

query3 = "SELECT wine.wine_name AS 'Wine Name', orders.bottles AS 'Bottles Ordered', " \
         "orders.order_date AS 'Date Bought' FROM orders INNER JOIN wine ON " \
         "wine.wine_id = orders.wine_id ORDER BY wine_name"
myCursor.execute(query3)
wine_bought = myCursor.fetchall()
for wine in wine_bought:
    print("Wine Name: {}\nNumber of Bottles Ordered: {}\nDate Bought: {}\n".format (wine[0],
        wine[1], wine[2]))