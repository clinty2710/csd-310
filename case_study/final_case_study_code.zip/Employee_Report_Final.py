from __future__ import print_function
import mysql.connector
from mysql.connector import errorcode

config = {
    'user': 'root',
    'password': 'Studman081!',
    'host': 'localhost',
    'database': 'bacchus_winery',
    'raise_on_warnings': True
}
try:
    mydb = mysql.connector.connect(**config)

    print("\n Database user {} connected to MySQL on host {} with database {}".format(
        config["user"], config["host"], config["database"]))
    input("\n\n Press any key to continue...\n")

except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print(" The supplied username or password are invalid")
    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print(" The specified database does not exist")
    else:
        print(err)

DB_NAME = 'bacchus_winery'

myCursor = mydb.cursor()

print("-Displaying Quarterly Payroll Information-")

query4 = "SELECT employees.first_name AS 'First Name', employees.last_name AS 'Last Name', " \
         "time_sheet.quarter_id AS 'Quarter', time_sheet.regular_hours_worked_quarterly AS 'Quarterly Hours Worked'," \
         "time_sheet.ot_worked_quarterly AS 'Quarterly Overtime Worked' FROM time_sheet INNER JOIN employees " \
         "ON employees.employee_id = time_sheet.employee_id"
myCursor.execute(query4)
payroll = myCursor.fetchall()
for hours_worked in payroll:
    print("Employee Name: {} {}\nWork Quarter: {}\nHours Worked: {}\nOvertime Hours: {}\n".format
          (hours_worked[0], hours_worked[1], hours_worked[2], hours_worked[3], hours_worked[4]))