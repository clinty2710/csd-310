from __future__ import print_function
import mysql.connector
from mysql.connector import errorcode

config = {
    'user': 'root',
    'password': 'Studman081!',
    'host': 'localhost',
    'database': 'bacchus_winery',
    'raise_on_warnings': True
}
try:
    mydb = mysql.connector.connect(**config)

    print("\n Database user {} connected to MySQL on host {} with database {}".format(
        config["user"], config["host"], config["database"]))
    input("\n\n Press any key to continue...\n")

except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print(" The supplied username or password are invalid")
    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print(" The specified database does not exist")
    else:
        print(err)

DB_NAME = 'bacchus_winery'

myCursor = mydb.cursor()

print("-Displaying Delivery Information-")

query1 = "SELECT deliveries.delivery_id AS 'Delivery Number', suppliers.supplier_name, " \
         "supplies.supply_name AS Supplies, deliveries.units AS 'Supply Count', " \
         "deliveries.expected_delivery_date AS 'Expected Delivery Date', " \
         "deliveries.actual_delivery_date AS 'Actual Delivery Date', " \
         "DATEDIFF(actual_delivery_date, expected_delivery_date) AS 'DateDiff' " \
         "FROM deliveries INNER JOIN supplies ON supplies.supply_id = deliveries.supply_id " \
         "INNER JOIN suppliers ON suppliers.supplier_id = deliveries.supplier_id ORDER BY " \
         "DateDiff, supplier_name"
myCursor.execute(query1)
deliveries = myCursor.fetchall()
for delivery in deliveries:
    print("Delivery Number: {}\nSupplier Name: {}\nSupply: {}\nSupply Count: {}\nExpected "
          "Delivery Date: {}\nActual Delivery Date: {}\nDelivery Timing Difference: {}\n".format(
        delivery[0], delivery[1], delivery[2], delivery[3], delivery[4], delivery[5],
        delivery[6]))
